## apple clone

### This is a clone of the apple website.
#### During the Christmas break, I decided to re-design the apple website and share it with you guys.

### Clone Display
![apple](https://user-images.githubusercontent.com/31680529/111058875-68cda800-845f-11eb-95e8-6f087e4718bb.jpg)


